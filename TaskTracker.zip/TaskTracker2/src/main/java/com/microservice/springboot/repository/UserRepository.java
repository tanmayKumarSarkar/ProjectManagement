package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.User;

public interface UserRepository extends CrudRepository<User, Long> {

	Iterable<User> findAllByUserProjectProjectId(Long id);
}
