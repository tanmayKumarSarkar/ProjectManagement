package com.microservice.springboot.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="Permission")
@EntityListeners(AuditingEntityListener.class)
public class Permission {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="permission_gen")
	@SequenceGenerator(name="permission_gen", sequenceName="permission_seq", allocationSize=1)
	private Long permissionId;
	
	private String permissionType;
	
	private String permissionLevel;

	public Long getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}

	public String getPermissionLevel() {
		return permissionLevel;
	}

	public void setPermissionLevel(String permissionLevel) {
		this.permissionLevel = permissionLevel;
	}

	@Override
	public String toString() {
		return "Permission [permissionId=" + permissionId + ", permissionType=" + permissionType + ", permissionLevel="
				+ permissionLevel + "]";
	}

	public void createPermission(String permissionType, String permissionLevel) {
		this.permissionType = permissionType;
		this.permissionLevel = permissionLevel;
	}

	public Permission(Long permissionId, String permissionType, String permissionLevel) {
		super();
		this.permissionId = permissionId;
		this.permissionType = permissionType;
		this.permissionLevel = permissionLevel;
	}

	public Permission() {
		super();
	}
	
	
	
	
	
	
	

}
