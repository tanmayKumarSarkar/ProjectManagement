package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.OutOfOffice;
import com.microservice.springboot.service.OutOfOfficeService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/outOfOffices")
public class OutOfOfficeController {
	
	@Autowired
	private OutOfOfficeService outOfOfficeService;
	
	@GetMapping(value="/all")
	public Iterable<OutOfOffice> getAllOutOfOffice () {
		return outOfOfficeService.findAll();
	}
	
	@PostMapping("/create")
	public OutOfOffice createOutOfOffice (@RequestBody OutOfOffice outOfOffice) {
		return outOfOfficeService.createOutOfOffice(outOfOffice);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateOutOfOffice(@RequestBody OutOfOffice outOfOffice) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(outOfOfficeService.findOutOfOfficeById(outOfOffice.getOutOfOfficeId())) {
			body.put("success", true);
			body.put("outOfOffice", outOfOfficeService.updateOutOfOffice(outOfOffice));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("outOfOffice", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteOutOfOffice(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(outOfOfficeService.findOutOfOfficeById(id)) {
			outOfOfficeService.deleteOutOfOffice(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@GetMapping("/user/{id}")
	public Iterable<OutOfOffice> findAllOutOfOfficePersonByUserId (@PathVariable Long id) {
		return outOfOfficeService.findAllOutOfOfficePersonByUserId(id);
	}
	
}
