package com.microservice.springboot.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name="OutOfOffice")
@EntityListeners(AuditingEntityListener.class)
public class OutOfOffice {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="outOfOffice_gen")
	@SequenceGenerator(name="outOfOffice_gen", sequenceName="outOfOffice_seq", allocationSize=1)
	private Long outOfOfficeId;
	
	@ManyToOne
	private User outOfOfficePerson;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDate outOfOfficeStartDate;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDate outOfOfficeEndDate;
	
	private String outOfOfficeType;
	
	private String outOfOfficeLeaveId;
		
	@Column(columnDefinition="TEXT")
	private String outOfOfficeReason;
	
	private Boolean outOfOfficeAvailed;
	
	private Integer outOfOfficeDuration;

	public Long getOutOfOfficeId() {
		return outOfOfficeId;
	}

	public void setOutOfOfficeId(Long outOfOfficeId) {
		this.outOfOfficeId = outOfOfficeId;
	}

	public User getOutOfOfficePerson() {
		return outOfOfficePerson;
	}

	public void setOutOfOfficePerson(User outOfOfficePerson) {
		this.outOfOfficePerson = outOfOfficePerson;
	}

	public LocalDate getOutOfOfficeStartDate() {
		return outOfOfficeStartDate;
	}

	public void setOutOfOfficeStartDate(LocalDate outOfOfficeStartDate) {
		this.outOfOfficeStartDate = outOfOfficeStartDate;
	}

	public LocalDate getOutOfOfficeEndDate() {
		return outOfOfficeEndDate;
	}

	public void setOutOfOfficeEndDate(LocalDate outOfOfficeEndDate) {
		this.outOfOfficeEndDate = outOfOfficeEndDate;
	}

	public String getOutOfOfficeType() {
		return outOfOfficeType;
	}

	public void setOutOfOfficeType(String outOfOfficeType) {
		this.outOfOfficeType = outOfOfficeType;
	}

	public String getOutOfOfficeLeaveId() {
		return outOfOfficeLeaveId;
	}

	public void setOutOfOfficeLeaveId(String outOfOfficeLeaveId) {
		this.outOfOfficeLeaveId = outOfOfficeLeaveId;
	}

	public String getOutOfOfficeReason() {
		return outOfOfficeReason;
	}

	public void setOutOfOfficeReason(String outOfOfficeReason) {
		this.outOfOfficeReason = outOfOfficeReason;
	}

	public Boolean getOutOfOfficeAvailed() {
		return outOfOfficeAvailed;
	}

	public void setOutOfOfficeAvailed(Boolean outOfOfficeAvailed) {
		this.outOfOfficeAvailed = outOfOfficeAvailed;
	}

	public Integer getOutOfOfficeDuration() {
		return outOfOfficeDuration;
	}

	public void setOutOfOfficeDuration(Integer outOfOfficeDuration) {
		this.outOfOfficeDuration = outOfOfficeDuration;
	}

	@Override
	public String toString() {
		return "OutOfOffice [outOfOfficeId=" + outOfOfficeId + ", outOfOfficePerson=" + outOfOfficePerson
				+ ", outOfOfficeStartDate=" + outOfOfficeStartDate + ", outOfOfficeEndDate=" + outOfOfficeEndDate
				+ ", outOfOfficeType=" + outOfOfficeType + ", outOfOfficeLeaveId=" + outOfOfficeLeaveId
				+ ", outOfOfficeReason=" + outOfOfficeReason + ", outOfOfficeAvailed=" + outOfOfficeAvailed
				+ ", outOfOfficeDuration=" + outOfOfficeDuration + "]";
	}

}
