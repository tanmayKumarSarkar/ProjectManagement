package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.TaskComplexity;
import com.microservice.springboot.repository.TaskComplexityRepository;

@Service
public class TaskComplexityService {

	@Autowired
	private TaskComplexityRepository taskComplexityRepo;
	
	public Iterable<TaskComplexity> findAll() {
		return taskComplexityRepo.findAll();
	}
	
	public TaskComplexity createTaskComplexity(TaskComplexity taskComplexity) {
		return taskComplexityRepo.save(taskComplexity);
	}
	
	public TaskComplexity updateTaskComplexity(TaskComplexity taskComplexity) {
		return taskComplexityRepo.save(taskComplexity);
	}

	public void deleteTaskComplexity(Long id) {
		taskComplexityRepo.deleteById(id);
	}

	public boolean findTaskComplexityById(Long taskComplexityId) {
		return taskComplexityRepo.existsById(taskComplexityId);
	}
	
}
