package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.TaskType;
import com.microservice.springboot.repository.TaskTypeRepository;

@Service
public class TaskTypeService {

	@Autowired
	private TaskTypeRepository taskTypeRepo;
	
	public Iterable<TaskType> findAll() {
		return taskTypeRepo.findAll();
	}
	
	public TaskType createTaskType(TaskType taskType) {
		return taskTypeRepo.save(taskType);
	}
	
	public TaskType updateTaskType(TaskType taskType) {
		return taskTypeRepo.save(taskType);
	}

	public void deleteTaskType(Long id) {
		taskTypeRepo.deleteById(id);
	}

	public boolean findTaskTypeById(Long taskTypeId) {
		return taskTypeRepo.existsById(taskTypeId);
	}
	
}
