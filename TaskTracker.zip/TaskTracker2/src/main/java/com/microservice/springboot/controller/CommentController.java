package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.Comment;
import com.microservice.springboot.service.CommentService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/comments")
public class CommentController {
	
	@Autowired
	private CommentService commentService;
	
	@GetMapping(value="/all")
	public Iterable<Comment> getAllComment () {
		return commentService.findAll();
	}
	
	@PostMapping("/create")
	public Comment createComment (@RequestBody Comment comment) {
		return commentService.createComment(comment);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateComment(@RequestBody Comment comment) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(commentService.findCommentById(comment.getCommentId())) {
			body.put("success", true);
			body.put("comment", commentService.updateComment(comment));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("comment", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteComment(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(commentService.findCommentById(id)) {
			commentService.deleteComment(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@GetMapping("/task/{id}")
	public Iterable<Comment> findAllByCommentsByTaskId (@PathVariable Long id) {
		return commentService.findAllByCommentByTaskId(id);
	}
	
}
