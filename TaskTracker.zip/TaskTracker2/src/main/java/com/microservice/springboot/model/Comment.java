package com.microservice.springboot.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="Comment")
@EntityListeners(AuditingEntityListener.class)
public class Comment {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="comment_gen")
	@SequenceGenerator(name="comment_gen", sequenceName="comment_seq", allocationSize=1)
	private Long commentId;
	
	@Column(columnDefinition="TEXT")
	private String commentDetails;
	
	private String commentType;
	
	@ManyToOne
	private User commentAuthor;
	
	@ManyToOne
	private Task commentTask;
	
	//@Temporal(TemporalType.DATE)
	//private Date commentTime;
	@CreationTimestamp
	private LocalDateTime commentTime;
	

	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public String getCommentDetails() {
		return commentDetails;
	}

	public void setCommentDetails(String commentDetails) {
		this.commentDetails = commentDetails;
	}

	public String getCommentType() {
		return commentType;
	}

	public void setCommentType(String commentType) {
		this.commentType = commentType;
	}

	public User getCommentAuthor() {
		return commentAuthor;
	}

	public void setCommentAuthor(User commentAuthor) {
		this.commentAuthor = commentAuthor;
	}

	public Task getCommentTask() {
		return commentTask;
	}

	public void setCommentTask(Task commentTask) {
		this.commentTask = commentTask;
	}

	public LocalDateTime getCommentTime() {
		return commentTime;
	}

	public void setCommentTime(LocalDateTime commentTime) {
		this.commentTime = commentTime;
	}

	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", commentDetails=" + commentDetails + ", commentType=" + commentType
				+ ", commentAuthor=" + commentAuthor + ", commentTime=" + commentTime + "]";
	}

	public void createComment(String commentDetails, String commentType, User commentAuthor, LocalDateTime commentTime) {
		this.commentDetails = commentDetails;
		this.commentType = commentType;
		this.commentAuthor = commentAuthor;
		this.commentTime = commentTime;
	}
	
	
	

}
