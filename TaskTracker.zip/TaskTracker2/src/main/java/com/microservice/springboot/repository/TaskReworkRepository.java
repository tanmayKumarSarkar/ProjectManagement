package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.TaskRework;

public interface TaskReworkRepository extends CrudRepository<TaskRework, Long> {

}
