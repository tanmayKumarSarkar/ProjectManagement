package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.TaskReworkType;

public interface TaskReworkTypeRepository extends CrudRepository<TaskReworkType, Long> {

}
