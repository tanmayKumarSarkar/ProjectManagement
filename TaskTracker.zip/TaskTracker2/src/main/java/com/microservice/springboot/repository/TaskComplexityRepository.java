package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.TaskComplexity;

public interface TaskComplexityRepository extends CrudRepository<TaskComplexity, Long> {

}
