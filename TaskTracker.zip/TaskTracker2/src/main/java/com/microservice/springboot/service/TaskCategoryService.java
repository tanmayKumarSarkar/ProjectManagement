package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.TaskCategory;
import com.microservice.springboot.repository.TaskCategoryRepository;

@Service
public class TaskCategoryService {

	@Autowired
	private TaskCategoryRepository taskCategoryRepo;
	
	public Iterable<TaskCategory> findAll() {
		return taskCategoryRepo.findAll();
	}
	
	public TaskCategory createTaskCategory(TaskCategory taskCategory) {
		return taskCategoryRepo.save(taskCategory);
	}
	
	public TaskCategory updateTaskCategory(TaskCategory taskCategory) {
		return taskCategoryRepo.save(taskCategory);
	}

	public void deleteTaskCategory(Long id) {
		taskCategoryRepo.deleteById(id);
	}

	public boolean findTaskCategoryById(Long taskCategoryId) {
		return taskCategoryRepo.existsById(taskCategoryId);
	}
	
}
