package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.Attachment;
import com.microservice.springboot.service.AttachmentService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/attachments")
public class AttachmentController {

	@Autowired
	private AttachmentService attachmentService;
	
	@GetMapping(value="/all")
	public Iterable<Attachment> getAllAttachment () {
		return attachmentService.findAll();
	}
	
	@PostMapping("/create")
	public Attachment createAttachment (@RequestBody Attachment attachment) {
		return attachmentService.createAttachment(attachment);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateAttachment(@RequestBody Attachment attachment) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(attachmentService.findAttachmentById(attachment.getAttachmentId())) {
			body.put("success", true);
			body.put("attachment", attachmentService.updateAttachment(attachment));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("attachment", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteAttachment(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(attachmentService.findAttachmentById(id)) {
			attachmentService.deleteAttachment(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}
	
}
