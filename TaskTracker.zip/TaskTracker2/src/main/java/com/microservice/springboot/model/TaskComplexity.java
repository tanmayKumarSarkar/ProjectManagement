package com.microservice.springboot.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="TaskComplexity")
@EntityListeners(AuditingEntityListener.class)
public class TaskComplexity {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="taskComplexity_gen")
	@SequenceGenerator(name="taskComplexity_gen", sequenceName="taskComplexity_seq", allocationSize=1)
	private Long taskComplexityId;
	
	private String taskComplexityName;

	public Long getTaskComplexityId() {
		return taskComplexityId;
	}

	public void setTaskComplexityId(Long taskComplexityId) {
		this.taskComplexityId = taskComplexityId;
	}

	public String getTaskComplexityName() {
		return taskComplexityName;
	}

	public void setTaskComplexityName(String taskComplexityName) {
		this.taskComplexityName = taskComplexityName;
	}

	@Override
	public String toString() {
		return "TaskComplexity [taskComplexityId=" + taskComplexityId + ", taskComplexityName=" + taskComplexityName + "]";
	}
	
	
}
