package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.Comment;
import com.microservice.springboot.repository.CommentRepository;

@Service
public class CommentService {

	@Autowired
	private CommentRepository commentRepo;
	
	public Iterable<Comment> findAll() {
		return commentRepo.findAll();
	}
	
	public Comment createComment(Comment comment) {
		return commentRepo.save(comment);
	}
	
	public Comment updateComment(Comment comment) {
		return commentRepo.save(comment);
	}

	public void deleteComment(Long id) {
		commentRepo.deleteById(id);
	}

	public boolean findCommentById(Long commentId) {
		return commentRepo.existsById(commentId);
	}
	
	public Iterable<Comment> findAllByCommentByTaskId(Long id) {
		return commentRepo.findAllByCommentTaskTaskId(id);
	}
	
}
