package com.microservice.springboot.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyErrorController implements ErrorController  {
 
    @RequestMapping("/error")
    public String handleError(HttpServletRequest request) {
        //do something like logging
    	return "error.html";
    	//return "redirect:/";
    }
 
    @Override
    public String getErrorPath() {
        return "/error";
    }
}