package com.microservice.springboot.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="TaskReworkType")
@EntityListeners(AuditingEntityListener.class)
public class TaskReworkType {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="taskReworkType_gen")
	@SequenceGenerator(name="taskReworkType_gen", sequenceName="taskReworkType_seq", allocationSize=1)
	private Long taskReworkTypeId;
	
	private String taskReworkTypeName;

	public Long getTaskReworkTypeId() {
		return taskReworkTypeId;
	}

	public void setTaskReworkTypeId(Long taskReworkTypeId) {
		this.taskReworkTypeId = taskReworkTypeId;
	}

	public String getTaskReworkTypeName() {
		return taskReworkTypeName;
	}

	public void setTaskReworkTypeName(String taskReworkTypeName) {
		this.taskReworkTypeName = taskReworkTypeName;
	}

	@Override
	public String toString() {
		return "TaskReworkType [taskReworkTypeId=" + taskReworkTypeId + ", taskReworkTypeName=" + taskReworkTypeName + "]";
	}

	
}
