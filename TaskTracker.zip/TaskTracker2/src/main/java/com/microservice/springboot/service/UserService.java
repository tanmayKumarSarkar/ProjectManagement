package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.User;
import com.microservice.springboot.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepo;
	
	public Iterable<User> findAll() {
		return userRepo.findAll();
	}
	
	public User createUser(User user) {
		return userRepo.save(user);
	}
	
	public User updateUser(User user) {
		return userRepo.save(user);
	}

	public void deleteUser(Long id) {
		userRepo.deleteById(id);
	}

	public boolean findUserById(Long userId) {
		return userRepo.existsById(userId);
	}
	
	public Iterable<User> findAllByUserByProject(Long projectId) {
		return userRepo.findAllByUserProjectProjectId(projectId);
	}
	
}
