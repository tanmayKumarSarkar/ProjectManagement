package com.microservice.springboot.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="TaskCategory")
@EntityListeners(AuditingEntityListener.class)
public class TaskCategory {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="taskCategory_gen")
	@SequenceGenerator(name="taskCategory_gen", sequenceName="taskCategory_seq", allocationSize=1)
	private Long taskCategoryId;
	
	private String taskCategoryName;

	public Long getTaskCategoryId() {
		return taskCategoryId;
	}

	public void setTaskCategoryId(Long taskCategoryId) {
		this.taskCategoryId = taskCategoryId;
	}

	public String getTaskCategoryName() {
		return taskCategoryName;
	}

	public void setTaskCategoryName(String taskCategoryName) {
		this.taskCategoryName = taskCategoryName;
	}

	@Override
	public String toString() {
		return "TaskCategory [taskCategoryId=" + taskCategoryId + ", taskCategoryName=" + taskCategoryName + "]";
	}
	
	
}
