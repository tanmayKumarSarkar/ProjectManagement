package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.TaskType;
import com.microservice.springboot.service.TaskTypeService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/tasktypes")
public class TaskTypeController {
	
	@Autowired
	private TaskTypeService taskTypeService;
	
	@GetMapping(value="/all")
	public Iterable<TaskType> getAllTaskType () {
		return taskTypeService.findAll();
	}
	
	@PostMapping("/create")
	public TaskType createTaskType (@RequestBody TaskType taskType) {
		return taskTypeService.createTaskType(taskType);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateTaskType(@RequestBody TaskType taskType) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskTypeService.findTaskTypeById(taskType.getTaskTypeId())) {
			body.put("success", true);
			body.put("taskType", taskTypeService.updateTaskType(taskType));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("taskType", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteTaskType(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskTypeService.findTaskTypeById(id)) {
			taskTypeService.deleteTaskType(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}

}
