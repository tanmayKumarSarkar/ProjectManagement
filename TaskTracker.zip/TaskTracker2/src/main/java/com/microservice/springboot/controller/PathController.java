package com.microservice.springboot.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class PathController {
	
	@RequestMapping(value = "/{[path:[^\\.]*}/*")
	public String userRedirectwithSlash(HttpServletRequest request) {
		System.out.println("DEFAULT REDIRECT :"+ request.getRequestURL()+" : "+request.getRequestURI());
        return "redirect:/";
	}
	
	@RequestMapping(value = "{path:[^\\.]*}")
	public String userRedirect(HttpServletRequest request) {
		System.out.println("DEFAULT FORWARD :"+ request.getRequestURL()+" : "+request.getRequestURI());
		if(request.getRequestURI().endsWith("/")) return "redirect:/";
		else return "forward:/";
	}

}
