package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.Attachment;

public interface AttachmentRepository extends CrudRepository<Attachment, Long> {

}
