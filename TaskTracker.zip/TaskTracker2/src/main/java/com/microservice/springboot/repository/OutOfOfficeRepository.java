package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.OutOfOffice;

public interface OutOfOfficeRepository extends CrudRepository<OutOfOffice, Long> {

	 public Iterable<OutOfOffice> findAllByOutOfOfficePersonUserId (long id);
}
