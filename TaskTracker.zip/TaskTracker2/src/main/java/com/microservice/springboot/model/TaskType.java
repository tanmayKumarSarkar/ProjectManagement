package com.microservice.springboot.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="TaskType")
@EntityListeners(AuditingEntityListener.class)
public class TaskType {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="taskType_gen")
	@SequenceGenerator(name="taskType_gen", sequenceName="taskType_seq", allocationSize=1)
	private Long taskTypeId;
	
	private String taskTypeName;

	public Long getTaskTypeId() {
		return taskTypeId;
	}

	public void setTaskTypeId(Long taskTypeId) {
		this.taskTypeId = taskTypeId;
	}

	public String getTaskTypeName() {
		return taskTypeName;
	}

	public void setTaskTypeName(String taskTypeName) {
		this.taskTypeName = taskTypeName;
	}

	@Override
	public String toString() {
		return "TaskType [taskTypeId=" + taskTypeId + ", taskTypeName=" + taskTypeName + "]";
	}
	
	
}
