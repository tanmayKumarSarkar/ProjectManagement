package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.Permission;

public interface PermissionRepository extends CrudRepository<Permission, Long> {

}
