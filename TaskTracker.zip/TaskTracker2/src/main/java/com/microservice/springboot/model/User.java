package com.microservice.springboot.model;

import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="User")
@EntityListeners(AuditingEntityListener.class)
public class User {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="user_gen")
	@SequenceGenerator(name="user_gen", sequenceName="user_seq", allocationSize=1)
	private Long userId;
	
	private String userFirstName;
	
	private String userLastName;
	
	private String userSoeid;

	private String userRole;
	
	@ManyToMany(fetch=FetchType.EAGER)
	private List<Permission> userPermission;
	
	@ManyToMany(fetch=FetchType.EAGER)
	private Set<Project> userProject;
	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)    
	private String password;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	
	public String getUserSoeid() {
		return userSoeid;
	}

	public void setUserSoeid(String userSoeid) {
		this.userSoeid = userSoeid;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Set<Project> getUserProject() {
		return userProject;
	}

	public void setUserProject(Set<Project> userProject) {
		this.userProject = userProject;
	}

	public List<Permission> getUserPermission() {
		return userPermission;
	}

	public void setUserPermission(List<Permission> userPermission) {
		this.userPermission = userPermission;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userSoeid=" + userSoeid + ", userRole=" + userRole + ", userPermission=" + userPermission
				+ ", userProject=" + userProject + "]";
	}

		

}
