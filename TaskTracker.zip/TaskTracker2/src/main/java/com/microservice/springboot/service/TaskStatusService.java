package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.TaskStatus;
import com.microservice.springboot.repository.TaskStatusRepository;

@Service
public class TaskStatusService {

	@Autowired
	private TaskStatusRepository taskStatusRepo;
	
	public Iterable<TaskStatus> findAll() {
		return taskStatusRepo.findAll();
	}
	
	public TaskStatus createTaskStatus(TaskStatus taskStatus) {
		return taskStatusRepo.save(taskStatus);
	}
	
	public TaskStatus updateTaskStatus(TaskStatus taskStatus) {
		return taskStatusRepo.save(taskStatus);
	}

	public void deleteTaskStatus(Long id) {
		taskStatusRepo.deleteById(id);
	}

	public boolean findTaskStatusById(Long taskStatusId) {
		return taskStatusRepo.existsById(taskStatusId);
	}
	
}
