package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.Project;
import com.microservice.springboot.repository.ProjectRepository;

@Service
public class ProjectService {

	@Autowired
	private ProjectRepository projectRepo;
	
	public Iterable<Project> findAll() {
		return projectRepo.findAll();
	}
	
	public Project createProject(Project project) {
		return projectRepo.save(project);
	}
	
	public Project updateProject(Project project) {
		return projectRepo.save(project);
	}

	public void deleteProject(Long id) {
		projectRepo.deleteById(id);
	}

	public boolean findProjectById(Long projectId) {
		return projectRepo.existsById(projectId);
	}
	
}
