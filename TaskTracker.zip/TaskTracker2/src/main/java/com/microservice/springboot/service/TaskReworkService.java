package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.TaskRework;
import com.microservice.springboot.repository.TaskReworkRepository;

@Service
public class TaskReworkService {

	@Autowired
	private TaskReworkRepository taskReworkRepo;
	
	public Iterable<TaskRework> findAll() {
		return taskReworkRepo.findAll();
	}
	
	public TaskRework createTaskRework(TaskRework taskRework) {
		return taskReworkRepo.save(taskRework);
	}
	
	public TaskRework updateTaskRework(TaskRework taskRework) {
		return taskReworkRepo.save(taskRework);
	}

	public void deleteTaskRework(Long id) {
		taskReworkRepo.deleteById(id);
	}

	public boolean findTaskReworkById(Long taskReworkId) {
		return taskReworkRepo.existsById(taskReworkId);
	}
	
}
