package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.TaskCategory;

public interface TaskCategoryRepository extends CrudRepository<TaskCategory, Long> {

}
