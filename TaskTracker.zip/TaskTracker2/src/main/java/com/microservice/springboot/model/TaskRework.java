package com.microservice.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="TaskRework")
@EntityListeners(AuditingEntityListener.class)
public class TaskRework {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="taskRework_gen")
	@SequenceGenerator(name="taskRework_gen", sequenceName="taskRework_seq", allocationSize=1)
	private Long taskReworkId;
	
	@ManyToOne
	private TaskReworkType taskReworkType;
	
	@ManyToOne
	private Task taskReworkParent;
	
	@Column(columnDefinition="TEXT")
	private String taskReworkDescription;
	
	private Integer taskReworkDuration;

	public Long getTaskReworkId() {
		return taskReworkId;
	}

	public void setTaskReworkId(Long taskReworkId) {
		this.taskReworkId = taskReworkId;
	}

	public TaskReworkType getTaskReworkType() {
		return taskReworkType;
	}

	public void setTaskReworkType(TaskReworkType taskReworkType) {
		this.taskReworkType = taskReworkType;
	}

	public Task getTaskReworkParent() {
		return taskReworkParent;
	}

	public void setTaskReworkParent(Task taskReworkParent) {
		this.taskReworkParent = taskReworkParent;
	}

	public String getTaskReworkDescription() {
		return taskReworkDescription;
	}

	public void setTaskReworkDescription(String taskReworkDescription) {
		this.taskReworkDescription = taskReworkDescription;
	}

	public Integer getTaskReworkDuration() {
		return taskReworkDuration;
	}

	public void setTaskReworkDuration(Integer taskReworkDuration) {
		this.taskReworkDuration = taskReworkDuration;
	}

	@Override
	public String toString() {
		return "TaskRework [taskReworkId=" + taskReworkId + ", taskReworkType=" + taskReworkType + ", taskReworkParent="
				+ taskReworkParent + ", taskReworkDescription=" + taskReworkDescription + ", taskReworkDuration="
				+ taskReworkDuration + "]";
	}
	
	
}
