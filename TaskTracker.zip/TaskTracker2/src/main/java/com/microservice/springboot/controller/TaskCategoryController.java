package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.TaskCategory;
import com.microservice.springboot.service.TaskCategoryService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/taskcatagories")
public class TaskCategoryController {
	
	@Autowired
	private TaskCategoryService taskCategoryService;
	
	@GetMapping(value="/all")
	public Iterable<TaskCategory> getAllTaskCategory () {
		return taskCategoryService.findAll();
	}
	
	@PostMapping("/create")
	public TaskCategory createTaskCategory (@RequestBody TaskCategory taskCategory) {
		return taskCategoryService.createTaskCategory(taskCategory);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateTaskCategory(@RequestBody TaskCategory taskCategory) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskCategoryService.findTaskCategoryById(taskCategory.getTaskCategoryId())) {
			body.put("success", true);
			body.put("taskCategory", taskCategoryService.updateTaskCategory(taskCategory));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("taskCategory", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteTaskCategory(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskCategoryService.findTaskCategoryById(id)) {
			taskCategoryService.deleteTaskCategory(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}

}
