package com.microservice.springboot.model;

import java.time.LocalDateTime;
//import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

//import com.fasterxml.jackson.databind.annotation.JsonSerialize;
//import com.microservice.springboot.json.JsonDateSerializer;

@Entity
@Table(name="Attachment")
@EntityListeners(AuditingEntityListener.class)
public class Attachment {
	
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="attachment_gen")
	@SequenceGenerator(name="attachment_gen", sequenceName="attachment_seq", allocationSize=1)
	private Long attachmentId;
	
	private String attachmentName;
	
	private String attachmentType;
	
	private String attachmentDetails;
	
	private String attachmentUrl;
	
	@ManyToOne
	private Task attachmentTask;
	
	@ManyToOne
	private User attachmentAuthor;

	@CreationTimestamp
	private LocalDateTime attachmentTime;

	public Long getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(Long attachmentId) {
		this.attachmentId = attachmentId;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getAttachmentDetails() {
		return attachmentDetails;
	}

	public void setAttachmentDetails(String attachmentDetails) {
		this.attachmentDetails = attachmentDetails;
	}

	public String getAttachmentUrl() {
		return attachmentUrl;
	}

	public void setAttachmentUrl(String attachmentUrl) {
		this.attachmentUrl = attachmentUrl;
	}

	public Task getAttachmentTask() {
		return attachmentTask;
	}

	public void setAttachmentTask(Task attachmentTask) {
		this.attachmentTask = attachmentTask;
	}

	public User getAttachmentAuthor() {
		return attachmentAuthor;
	}

	public void setAttachmentAuthor(User attachmentAuthor) {
		this.attachmentAuthor = attachmentAuthor;
	}

	//@JsonSerialize(using= JsonDateSerializer.class)
	public LocalDateTime getAttachmentTime() {
		return attachmentTime;
	}

	public void setAttachmentTime(LocalDateTime attachmentTime) {
		this.attachmentTime = attachmentTime;
	}

	@Override
	public String toString() {
		return "Attachment [attachmentId=" + attachmentId + ", attachmentName=" + attachmentName + ", attachmentType="
				+ attachmentType + ", attachmentDetails=" + attachmentDetails + ", attachmentUrl=" + attachmentUrl
				+ ", attachmentTask=" + attachmentTask + ", attachmentAuthor=" + attachmentAuthor + ", attachmentTime="
				+ attachmentTime + "]";
	}

	public void createAttachment(Long attachmentId, String attachmentName, String attachmentType, String attachmentDetails,
			String attachmentUrl, Task attachmentTask, User attachmentAuthor, LocalDateTime attachmentTime) {
		this.attachmentId = attachmentId;
		this.attachmentName = attachmentName;
		this.attachmentType = attachmentType;
		this.attachmentDetails = attachmentDetails;
		this.attachmentUrl = attachmentUrl;
		this.attachmentTask = attachmentTask;
		this.attachmentAuthor = attachmentAuthor;
		this.attachmentTime = attachmentTime;
	}
	

}
