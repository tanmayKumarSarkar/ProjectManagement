package com.microservice.springboot.model;


import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name="Task")
@EntityListeners(AuditingEntityListener.class)
public class Task {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="task_gen")
	@SequenceGenerator(name="task_gen", sequenceName="task_seq", allocationSize=1)
	private Long taskId;
	
	private String taskName;
	
	@ManyToOne
	private TaskType taskType;
	
	@ManyToOne
	private Project project;
	
	private String trackingNumber;
	
	@Column(columnDefinition="TEXT")
	private String taskDescription;
	
	private Integer priority;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDate taskStartDate;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDate taskDevEndDate;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDate taskUatEndDate;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDate taskProdEndDate;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime taskCreateDate;
	
	@ManyToOne
	private TaskStatus taskStatus;
	
	//Actual Effort
	private Integer taskEffort; 
	
	//Planned Effort
	private Integer taskPlannedEffort; 
	
	@ManyToOne
	private TaskComplexity taskComplexity;
	
	@ManyToOne
	private TaskCategory taskCategory;
	
	@ManyToOne
	private User taskAsignee;
	
//	@OneToMany(fetch=FetchType.EAGER)
//	@Fetch(value = FetchMode.SUBSELECT)
//	//@OneToMany(targetEntity = Comment.class, fetch=FetchType.EAGER)
//	private List<Comment> taskComments;
	
	@ManyToOne
	private User taskReviewer;
	
	@Column(columnDefinition="TEXT")
	private String taskArtifactDetails;
	
	@Column(columnDefinition="TEXT")
	private String taskCheckpoint;
	
	@OneToOne
	private TaskRework taskRework;

	
	//Getter Setters
	
	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public TaskType getTaskType() {
		return taskType;
	}

	public void setTaskType(TaskType taskType) {
		this.taskType = taskType;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public LocalDate getTaskStartDate() {
		return taskStartDate;
	}

	public void setTaskStartDate(LocalDate taskStartDate) {
		this.taskStartDate = taskStartDate;
	}

	public LocalDate getTaskDevEndDate() {
		return taskDevEndDate;
	}

	public void setTaskDevEndDate(LocalDate taskDevEndDate) {
		this.taskDevEndDate = taskDevEndDate;
	}

	public LocalDate getTaskUatEndDate() {
		return taskUatEndDate;
	}

	public void setTaskUatEndDate(LocalDate taskUatEndDate) {
		this.taskUatEndDate = taskUatEndDate;
	}

	public LocalDate getTaskProdEndDate() {
		return taskProdEndDate;
	}

	public void setTaskProdEndDate(LocalDate taskProdEndDate) {
		this.taskProdEndDate = taskProdEndDate;
	}
	
	public LocalDateTime getTaskCreateDate() {
		return taskCreateDate;
	}

	public void setTaskCreateDate(LocalDateTime taskCreateDate) {
		this.taskCreateDate = taskCreateDate;
	}
	
	public TaskStatus getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(TaskStatus taskStatus) {
		this.taskStatus = taskStatus;
	}

	public Integer getTaskEffort() {
		return taskEffort;
	}

	public void setTaskEffort(Integer taskEffort) {
		this.taskEffort = taskEffort;
	}

	public Integer getTaskPlannedEffort() {
		return taskPlannedEffort;
	}

	public void setTaskPlannedEffort(Integer taskPlannedEffort) {
		this.taskPlannedEffort = taskPlannedEffort;
	}

	public TaskComplexity getTaskComplexity() {
		return taskComplexity;
	}

	public void setTaskComplexity(TaskComplexity taskComplexity) {
		this.taskComplexity = taskComplexity;
	}

	public TaskCategory getTaskCategory() {
		return taskCategory;
	}

	public void setTaskCategory(TaskCategory taskCategory) {
		this.taskCategory = taskCategory;
	}

	public User getTaskAsignee() {
		return taskAsignee;
	}

	public void setTaskAsignee(User taskAsignee) {
		this.taskAsignee = taskAsignee;
	}

	public User getTaskReviewer() {
		return taskReviewer;
	}

	public void setTaskReviewer(User taskReviewer) {
		this.taskReviewer = taskReviewer;
	}

	public String getTaskArtifactDetails() {
		return taskArtifactDetails;
	}

	public void setTaskArtifactDetails(String taskArtifactDetails) {
		this.taskArtifactDetails = taskArtifactDetails;
	}
	
	public String getTaskCheckpoint() {
		return taskCheckpoint;
	}

	public void setTaskCheckpoint(String taskCheckpoint) {
		this.taskCheckpoint = taskCheckpoint;
	}

	public TaskRework getTaskRework() {
		return taskRework;
	}

	public void setTaskRework(TaskRework taskRework) {
		this.taskRework = taskRework;
	}

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", taskName=" + taskName + ", taskType=" + taskType + ", project=" + project
				+ ", trackingNumber=" + trackingNumber + ", taskDescription=" + taskDescription + ", priority="
				+ priority + ", taskStartDate=" + taskStartDate + ", taskDevEndDate=" + taskDevEndDate
				+ ", taskUatEndDate=" + taskUatEndDate + ", taskProdEndDate=" + taskProdEndDate + ", taskCreateDate="
				+ taskCreateDate + ", taskStatus=" + taskStatus + ", taskEffort=" + taskEffort + ", taskPlannedEffort="
				+ taskPlannedEffort + ", taskComplexity=" + taskComplexity + ", taskCategory=" + taskCategory
				+ ", taskAsignee=" + taskAsignee + ", taskReviewer=" + taskReviewer + ", taskArtifactDetails="
				+ taskArtifactDetails + ", taskCheckpoint=" + taskCheckpoint + ", taskRework=" + taskRework + "]";
	}

	public Task() {
	}

	public Task(Long taskId, String taskName, TaskType taskType, Project project, String trackingNumber,
			String taskDescription, Integer priority, LocalDate taskStartDate, LocalDate taskDevEndDate,
			LocalDate taskUatEndDate, LocalDate taskProdEndDate, LocalDateTime taskCreateDate, TaskStatus taskStatus,
			Integer taskEffort, Integer taskPlannedEffort, TaskComplexity taskComplexity, TaskCategory taskCategory,
			User taskAsignee, User taskReviewer, String taskArtifactDetails, String taskCheckpoint,
			TaskRework taskRework) {
		super();
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskType = taskType;
		this.project = project;
		this.trackingNumber = trackingNumber;
		this.taskDescription = taskDescription;
		this.priority = priority;
		this.taskStartDate = taskStartDate;
		this.taskDevEndDate = taskDevEndDate;
		this.taskUatEndDate = taskUatEndDate;
		this.taskProdEndDate = taskProdEndDate;
		this.taskCreateDate = taskCreateDate;
		this.taskStatus = taskStatus;
		this.taskEffort = taskEffort;
		this.taskPlannedEffort = taskPlannedEffort;
		this.taskComplexity = taskComplexity;
		this.taskCategory = taskCategory;
		this.taskAsignee = taskAsignee;
		this.taskReviewer = taskReviewer;
		this.taskArtifactDetails = taskArtifactDetails;
		this.taskCheckpoint = taskCheckpoint;
		this.taskRework = taskRework;
	}

	
}
