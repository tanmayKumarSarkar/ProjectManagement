package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.OutOfOffice;
import com.microservice.springboot.repository.OutOfOfficeRepository;

@Service
public class OutOfOfficeService {

	@Autowired
	private OutOfOfficeRepository outOfOfficeRepo;
	
	public Iterable<OutOfOffice> findAll() {
		return outOfOfficeRepo.findAll();
	}
	
	public OutOfOffice createOutOfOffice(OutOfOffice outOfOffice) {
		return outOfOfficeRepo.save(outOfOffice);
	}
	
	public OutOfOffice updateOutOfOffice(OutOfOffice outOfOffice) {
		return outOfOfficeRepo.save(outOfOffice);
	}

	public void deleteOutOfOffice(Long id) {
		outOfOfficeRepo.deleteById(id);
	}

	public boolean findOutOfOfficeById(Long outOfOfficeId) {
		return outOfOfficeRepo.existsById(outOfOfficeId);
	}
	
	public Iterable<OutOfOffice> findAllOutOfOfficePersonByUserId (long id){
		return outOfOfficeRepo.findAllByOutOfOfficePersonUserId(id);
	}
	
}
