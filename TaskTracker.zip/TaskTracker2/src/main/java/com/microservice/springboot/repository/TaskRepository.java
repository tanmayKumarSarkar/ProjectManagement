package com.microservice.springboot.repository;

import java.util.Set;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.Task;

public interface TaskRepository extends CrudRepository<Task, Long> {
	
	Set<Task> findAllByTaskAsigneeUserId (Long id);
	
}
