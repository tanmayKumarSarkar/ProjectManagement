package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.User;
import com.microservice.springboot.service.UserService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;
	
	@GetMapping(value="/all")
	public Iterable<User> getAllUser () {
		return userService.findAll();
	}
	
	@PostMapping("/create")
	public User createUser (@RequestBody User user) {
		return userService.createUser(user);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateUser(@RequestBody User user) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(userService.findUserById(user.getUserId())) {
			body.put("success", true);
			body.put("user", userService.updateUser(user));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("user", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteUser(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(userService.findUserById(id)) {
			userService.deleteUser(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@GetMapping(value="/project/{projectId}")
	public Iterable<User> findAllByUserByProject (@PathVariable Long projectId) {
		return userService.findAllByUserByProject(projectId);
	}
	
	
}
