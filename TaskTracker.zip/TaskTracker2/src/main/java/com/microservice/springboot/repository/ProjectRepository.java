package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.Project;

public interface ProjectRepository extends CrudRepository<Project, Long> {

}
