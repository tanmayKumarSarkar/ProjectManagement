package com.microservice.springboot.service;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.Task;
import com.microservice.springboot.repository.TaskRepository;

@Service
public class TaskService {

	@Autowired
	private TaskRepository taskRepo;
	
	public Iterable<Task> findAll() {
		return taskRepo.findAll();
	}

	public Task createTask(Task task) {
		return taskRepo.save(task);
	}

	public Task updateTask(Task task) {
		return taskRepo.save(task);
	}

	public void deleteTask(Long id) {
		taskRepo.deleteById(id);
	}

	public boolean findTaskById(Long taskId) {
		return taskRepo.existsById(taskId);
	}

	public Task findById(Long id) {
		return taskRepo.findById(id).orElse(null);
	}
	
	public Set<Task> findAllByTaskUserUserId(Set<Long> ids) {
		Set<Task> reportTask = new HashSet<Task>();
		Iterator<Long> itID = ids.iterator();
	     while(itID.hasNext()){
	    	 reportTask.addAll(taskRepo.findAllByTaskAsigneeUserId(itID.next()));
	     }
		return reportTask;
	}

}
