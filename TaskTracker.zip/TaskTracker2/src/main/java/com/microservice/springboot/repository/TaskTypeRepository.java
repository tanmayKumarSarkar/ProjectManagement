package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.TaskType;

public interface TaskTypeRepository extends CrudRepository<TaskType, Long> {

}
