package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.TaskStatus;
import com.microservice.springboot.service.TaskStatusService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/taskstatuses")
public class TaskStatusController {
	
	@Autowired
	private TaskStatusService taskStatusService;
	
	@GetMapping(value="/all")
	public Iterable<TaskStatus> getAllTaskStatus () {
		return taskStatusService.findAll();
	}
	
	@PostMapping("/create")
	public TaskStatus createTaskStatus (@RequestBody TaskStatus taskStatus) {
		return taskStatusService.createTaskStatus(taskStatus);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateTaskStatus(@RequestBody TaskStatus taskStatus) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskStatusService.findTaskStatusById(taskStatus.getTaskStatusId())) {
			body.put("success", true);
			body.put("taskStatus", taskStatusService.updateTaskStatus(taskStatus));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("taskStatus", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteTaskStatus(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskStatusService.findTaskStatusById(id)) {
			taskStatusService.deleteTaskStatus(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}

}
