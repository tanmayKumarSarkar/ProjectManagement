package com.microservice.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.springboot.model.Comment;

public interface CommentRepository extends CrudRepository<Comment, Long> {

	 public Iterable<Comment> findAllByCommentTaskTaskId (Long id);
}
