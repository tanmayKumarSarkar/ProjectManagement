package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.TaskReworkType;
import com.microservice.springboot.repository.TaskReworkTypeRepository;

@Service
public class TaskReworkTypeService {

	@Autowired
	private TaskReworkTypeRepository taskReworkTypeRepo;
	
	public Iterable<TaskReworkType> findAll() {
		return taskReworkTypeRepo.findAll();
	}
	
	public TaskReworkType createTaskReworkType(TaskReworkType taskReworkType) {
		return taskReworkTypeRepo.save(taskReworkType);
	}
	
	public TaskReworkType updateTaskReworkType(TaskReworkType taskReworkType) {
		return taskReworkTypeRepo.save(taskReworkType);
	}

	public void deleteTaskReworkType(Long id) {
		taskReworkTypeRepo.deleteById(id);
	}

	public boolean findTaskReworkTypeById(Long taskReworkTypeId) {
		return taskReworkTypeRepo.existsById(taskReworkTypeId);
	}
	
}
