package com.microservice.springboot.json;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class JsonDateSerializer extends JsonSerializer<Date> {
	
	private static final SimpleDateFormat dateformat = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");

	@Override
	public void serialize(Date dt, JsonGenerator gen, SerializerProvider serializers) throws IOException {
		String formattedDate = dateformat.format(dt);
		gen.writeString(formattedDate);
	}

}
