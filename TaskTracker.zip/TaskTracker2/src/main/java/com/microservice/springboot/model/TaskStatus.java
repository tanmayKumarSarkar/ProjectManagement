package com.microservice.springboot.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="TaskStatus")
@EntityListeners(AuditingEntityListener.class)
public class TaskStatus {

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="taskStatus_gen")
	@SequenceGenerator(name="taskStatus_gen", sequenceName="taskStatus_seq", allocationSize=1)
	private Long taskStatusId;
	
	private String taskStatusName;

	public Long getTaskStatusId() {
		return taskStatusId;
	}

	public void setTaskStatusId(Long taskStatusId) {
		this.taskStatusId = taskStatusId;
	}

	public String getTaskStatusName() {
		return taskStatusName;
	}

	public void setTaskStatusName(String taskStatusName) {
		this.taskStatusName = taskStatusName;
	}

	@Override
	public String toString() {
		return "TaskStatus [taskStatusId=" + taskStatusId + ", taskStatusName=" + taskStatusName + "]";
	}
	
	
}
