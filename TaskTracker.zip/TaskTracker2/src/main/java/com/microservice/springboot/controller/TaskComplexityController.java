package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.TaskComplexity;
import com.microservice.springboot.service.TaskComplexityService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/taskcomplexities")
public class TaskComplexityController {
	
	@Autowired
	private TaskComplexityService taskComplexityService;
	
	@GetMapping(value="/all")
	public Iterable<TaskComplexity> getAllTaskComplexity () {
		return taskComplexityService.findAll();
	}
	
	@PostMapping("/create")
	public TaskComplexity createTaskComplexity (@RequestBody TaskComplexity taskComplexity) {
		return taskComplexityService.createTaskComplexity(taskComplexity);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateTaskComplexity(@RequestBody TaskComplexity taskComplexity) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskComplexityService.findTaskComplexityById(taskComplexity.getTaskComplexityId())) {
			body.put("success", true);
			body.put("taskComplexity", taskComplexityService.updateTaskComplexity(taskComplexity));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("taskComplexity", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteTaskComplexity(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskComplexityService.findTaskComplexityById(id)) {
			taskComplexityService.deleteTaskComplexity(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}

}
