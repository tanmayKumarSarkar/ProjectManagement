package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.Attachment;
import com.microservice.springboot.repository.AttachmentRepository;

@Service
public class AttachmentService {

	@Autowired
	private AttachmentRepository attachmentRepo;
	
	public Iterable<Attachment> findAll() {
		return attachmentRepo.findAll();
	}
	
	public Attachment createAttachment(Attachment attachment) {
		return attachmentRepo.save(attachment);
	}
	
	public Attachment updateAttachment(Attachment attachment) {
		return attachmentRepo.save(attachment);
	}

	public void deleteAttachment(Long id) {
		attachmentRepo.deleteById(id);
	}

	public boolean findAttachmentById(Long attachmentId) {
		return attachmentRepo.existsById(attachmentId);
	}
	
}
