package com.microservice.springboot.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.springboot.model.TaskRework;
import com.microservice.springboot.service.TaskReworkService;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/taskreworks")
public class TaskReworkController {
	
	@Autowired
	private TaskReworkService taskReworkService;
	
	@GetMapping(value="/all")
	public Iterable<TaskRework> getAllTaskRework () {
		return taskReworkService.findAll();
	}
	
	@PostMapping("/create")
	public TaskRework createTaskRework (@RequestBody TaskRework taskRework) {
		return taskReworkService.createTaskRework(taskRework);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateTaskRework(@RequestBody TaskRework taskRework) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskReworkService.findTaskReworkById(taskRework.getTaskReworkId())) {
			body.put("success", true);
			body.put("taskRework", taskReworkService.updateTaskRework(taskRework));
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			body.put("taskRework", null);
			return ResponseEntity.ok().body(body);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteTaskRework(@PathVariable Long id) {
		
		HashMap<String, Object> body = new HashMap<>();
		if(taskReworkService.findTaskReworkById(id)) {
			taskReworkService.deleteTaskRework(id);
			body.put("success", true);
			return ResponseEntity.ok().body(body);
		}else {
			body.put("success", false);
			return ResponseEntity.ok().body(body);
		}
	}

}
