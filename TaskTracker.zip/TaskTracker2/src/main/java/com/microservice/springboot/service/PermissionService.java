package com.microservice.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.springboot.model.Permission;
import com.microservice.springboot.repository.PermissionRepository;

@Service
public class PermissionService {

	@Autowired
	private PermissionRepository permissionRepo;
	
	public Iterable<Permission> findAll() {
		return permissionRepo.findAll();
	}
	
	public Permission createPermission(Permission permission) {
		return permissionRepo.save(permission);
	}
	
	public Permission updatePermission(Permission permission) {
		return permissionRepo.save(permission);
	}

	public void deletePermission(Long id) {
		permissionRepo.deleteById(id);
	}

	public boolean findPermissionById(Long permissionId) {
		return permissionRepo.existsById(permissionId);
	}
	
}
