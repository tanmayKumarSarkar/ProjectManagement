// environment.prod.ts
export const environment = {
  production: true,
  api: '/ProjectManagement/api'
}