import { Injectable } from '@angular/core';
import { Http, Headers } from '../../../node_modules/@angular/http';
import { environment } from '../../environments/environment';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ReportService {

  private hostApi = '/api';
  users;


  constructor(private http: Http) { 
    if(environment.production) this.hostApi = environment.api;
  }

  getUsersAssociatedToProjectDAO (prjId) {
    return this.http.get(`${this.hostApi}/users/project/${prjId}`)
      .pipe(map(res => res.json()));
  }

  getTasksByUsersDAO (users) {
    let headers = new Headers();
    headers.append('Content-type', 'application/json');
    return this.http.post(`${this.hostApi}/tasks/users`, users, {headers: headers} )
      .pipe(map(res => res.json()));     
  }
}
