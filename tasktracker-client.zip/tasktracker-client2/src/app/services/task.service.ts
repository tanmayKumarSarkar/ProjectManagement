import { Injectable, EventEmitter } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';

import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private hostApi = '/api'; //http://localhost:8080/api/';
  private _allTasks;
  private _allUsers;
  selectedViewEditTask;
  selectedAddViewTask;
  selectedTaskOnView;

  taskTypes;
  projects;
  taskStatuses;
  taskComplexities;
  taskCategories;
  taskRework;
  taskReworkTypes;

  constructor(private http: Http) {
    if(environment.production) this.hostApi = environment.api;
   }

  //tasks
  set allTasks(tasks) {this._allTasks = tasks};

  get allTasks(): Object { return this._allTasks};

  getAllTasksDAO () {
    return this.http.get(`${this.hostApi}/tasks/all`)
      .pipe(map(res => res.json()));
  }

  getTaskByIdDAO (id) {
    return this.http.get(`${this.hostApi}/tasks/showbyid/${id}`)
      .pipe(map(res => res.json()));      
  }

  saveTasksDAO (task) {
    let headers = new Headers();
    headers.append('Content-type', 'application/json');
    return this.http.post(`${this.hostApi}/tasks/create`,task, {headers: headers} )
      .pipe(map(res => res.json()));      
  }

  updateTasksDAO (task) {
    let headers = new Headers();
    headers.append('Content-type', 'application/json');
    return this.http.put(`${this.hostApi}/tasks/update`,task, {headers: headers} )
      .pipe(map(res => res.json()));      
  }

  deleteTasksDAO (id) {
    return this.http.delete(`${this.hostApi}/tasks/delete/${id}`)
      .pipe(map(res => res.json()));      
  }

  //users
  set allUsers(users) {this._allUsers = users};

  get allUsers(): Object { return this._allUsers};

  getAllUsersDAO () {
    return this.http.get(`${this.hostApi}/users/all`)
      .pipe(map(res => res.json()));      
  }

  getAllTaskTypesDAO () {
    return this.http.get(`${this.hostApi}/tasktypes/all`)
      .pipe(map(res => res.json()));      
  }

  getAllProjectsDAO () {
    return this.http.get(`${this.hostApi}/projects/all`)
      .pipe(map(res => res.json()));      
  }

  getAllTaskStatusesDAO () {
    return this.http.get(`${this.hostApi}/taskstatuses/all`)
      .pipe(map(res => res.json()));      
  }

  getAllTaskComplexitiesDAO () {
    return this.http.get(`${this.hostApi}/taskcomplexities/all`)
      .pipe(map(res => res.json()));      
  }

  getAllTaskCategoriesDAO () {
    return this.http.get(`${this.hostApi}/taskcatagories/all`)
      .pipe(map(res => res.json()));      
  }

  getAllTaskReworkTypesDAO () {
    return this.http.get(`${this.hostApi}/taskreworktypes/all`)
      .pipe(map(res => res.json()));      
  }

  saveTaskReworkDAO (taskRework) {
    let headers = new Headers();
    headers.append('Content-type', 'application/json');
    return this.http.post(`${this.hostApi}/taskreworks/create`,taskRework, {headers: headers} )
      .pipe(map(res => res.json()));      
  }

  getCommentsForTaskDAO(id){
    return this.http.get(`${this.hostApi}/comments/task/${id}`)
      .pipe(map(res => res.json())); 
  }

  saveTaskCommentDAO(comment){
    let headers = new Headers();
    headers.append('Content-type', 'application/json');
    return this.http.post(`${this.hostApi}/comments/create`, comment, {headers: headers} )
      .pipe(map(res => res.json())); 
  }

  //event emitter
  propertyChange: EventEmitter<String> = new EventEmitter<String>();

  triggerEvent(message) {
    this.propertyChange.emit(message);
  }

}
