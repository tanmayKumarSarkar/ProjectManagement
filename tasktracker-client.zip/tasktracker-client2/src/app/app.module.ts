import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { RouterModule, Routes } from '@angular/router';
import {NgxPaginationModule} from 'ngx-pagination';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { TaskHomeComponent } from './components/task-home/task-home.component';
import {ReportHomeComponent } from './components/report-home/report-home.component';
import { ViewTasksComponent } from './components/view-tasks/view-tasks.component';
import { AddTaskComponent } from './components/add-task/add-task.component';
import { EditTaskComponent } from './components/edit-task/edit-task.component';

import { TaskService } from './services/task.service';
import { AuthService } from './services/auth.service';
import { ClickOutsideDirective } from './directives/click-outside.directive';
import { TaskFilterPipe } from './pipes/task-filter.pipe';
import { TaskSortByPipe } from './pipes/task-sort-by.pipe';
import { ViewReportComponent } from './components/view-report/view-report.component';
import { TaskCommentComponent } from './components/task-comment/task-comment.component';

const appRoutes = [
  {path: '', component: HomeComponent},
  {path: 'task', component: TaskHomeComponent},
  {path: 'report', component: ReportHomeComponent},
  {path: '**', redirectTo: '', terminal: true}
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    TaskHomeComponent,
    ViewTasksComponent,
    ReportHomeComponent,
    AddTaskComponent,
    EditTaskComponent,
    ClickOutsideDirective,
    TaskFilterPipe,
    TaskSortByPipe,
    ViewReportComponent,
    TaskCommentComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    AngularFontAwesomeModule,
    RouterModule.forRoot(appRoutes),
    NgxPaginationModule
  ],
  providers: [
    TaskService,
    AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
