import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { ReportService } from '../../services/report.service';

@Component({
  selector: 'app-view-report',
  templateUrl: './view-report.component.html',
  styleUrls: ['./view-report.component.css']
})
export class ViewReportComponent implements OnInit {

  Math: any;
  projects;
  selectedProject;
  users;
  Select;
  selectedCheckBoxUsers = [];
  selectedCheckBoxUserIds = [];
  isSelectedAllUser = false;
  reportStartDate;
  reportEndDate;
  taskListOfUsers = [];
  totalTaskTime;
  effortPerDay = 7;
  effort: {
    userId: Number,
    userName: String,
    timeWorked: Number,
    task: {
      taskId: Number,
      taskName: String,
      taskTime: Number,
      taskStartDt: String,
      taskEndDt: String
    }[]
  };
  listEffort =[];
  selectedEffortTask;

  constructor(private taskService: TaskService, private reportService: ReportService) {
    this.Math = Math;
   }

  ngOnInit() {
    this.getAllProjects();
    //let curentDt = new Date;
    //this.reportStartDate = new Date(curentDt.setDate(curentDt.getDate() - curentDt.getDay()) + (curentDt.getDay() == 0 ? -6 : 1)).toISOString().split('T')[0];
    //this.reportEndDate = new Date(curentDt.setDate(curentDt.getDate() - curentDt.getDay()) + (curentDt.getDay() == 0 ? -1 : 6)).toISOString().split('T')[0];
    this.reportStartDate = this.getMonday();
    this.reportEndDate = this.getFriday();
  }

  getMonday() {
    let dt = new Date();
    let day = dt.getUTCDay(),
      dtDiff = dt.getUTCDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
    return new Date(dt.setUTCDate(dtDiff)).toISOString().split('T')[0];
  }

  getFriday() {
    let dt = new Date();
    let day = dt.getUTCDay(),
      dtDiff = dt.getUTCDate() - day + (day == 0 ? -2:5); // adjust when day is sunday
    return new Date(dt.setUTCDate(dtDiff)).toISOString().split('T')[0];
  }

  getAllProjects(){
    this.taskService.getAllProjectsDAO().subscribe(data => {
      this.projects = this.taskService.projects = data;
    });
  }

  selectedProjectChange(project){
    this.getUsersAssociatedToProject(project.projectId);
  }

  getUsersAssociatedToProject(projectId){
    this.reportService.getUsersAssociatedToProjectDAO(projectId).subscribe(data => {
      this.users = this.reportService.users = data;
    });
  }

  selectedUserChange(user){
    console.log(user);
  }

  getReport(){
    //console.log(this.selectedCheckBoxUsers, this.reportStartDate, this.reportEndDate);
    let users = [];
    this.listEffort = [];
    this.selectedEffortTask = undefined;
    this.getTasksByUsers(this.selectedCheckBoxUserIds, () => {
      this.totalTaskTime = this.getDateDifference(this.reportStartDate, this.reportEndDate)*this.effortPerDay;
      this.selectedCheckBoxUsers.forEach(user=> {
        let effortOverTimePerUser = 0;
        let taskItemArr=[];
        this.taskListOfUsers.forEach(task =>{
          if(user.userId == task.taskAsignee.userId){
            let effortOverTimePerTask = this.getTaskEffort(task.taskStartDate, task.taskDevEndDate, task.taskEffort);
            if(effortOverTimePerTask != 0){
              let taskItem = {
                taskId: task.taskId,
                taskName: task.taskName,
                taskTime: effortOverTimePerTask,
                taskStartDate: task.taskStartDate,
                taskEndDate: task.taskDevEndDate
              }
              taskItemArr.push(taskItem);
              effortOverTimePerUser = effortOverTimePerUser + effortOverTimePerTask;
            }
          }
        }); //End of task loop
        this.effort = {
          userId : user.userId,
          userName: user.userLastName+", "+user.userFirstName,          
          timeWorked: effortOverTimePerUser,
          task: taskItemArr
        }
        this.listEffort.push(this.effort);
      }); //End of user loop
    });
    console.log(this.listEffort);
  }

  getTaskEffort(tskStDt, tskEndDt, effort){
    let effortOverTime;
    let taskEffortPerDay;
    //if only task start & End date lies on or within report start & end date
    if ((this.getDateDifference(this.reportStartDate, tskEndDt) >0) && (this.getDateDifference(tskStDt, this.reportEndDate) >0)){
      // task starting before report date & ending after report end date
      if ((this.getDateDifference(tskStDt, this.reportStartDate) >1) && (this.getDateDifference(this.reportEndDate, tskEndDt) >1)){
        taskEffortPerDay = effort/this.getDateDifference(tskStDt, tskEndDt);
        return effortOverTime = this.getDateDifference(this.reportStartDate, this.reportEndDate)*taskEffortPerDay;
      }
      //both dates on same time frames
      // if ((this.getDateDifference(tskStDt, this.reportStartDate) ==1) && (this.getDateDifference(this.reportEndDate, tskEndDt) ==1)){
      //   effortOverTime = effort;
      // }
      //task time-frame within report time-frame && on same time frames
      if ((this.getDateDifference(this.reportStartDate, tskStDt) >0) && (this.getDateDifference(tskEndDt, this.reportEndDate) >0)){
        return effortOverTime = effort;
      }
      //report start time lies within task time-frame
      if ((this.getDateDifference(tskStDt, this.reportStartDate) >0) && (this.getDateDifference(tskEndDt, this.reportEndDate) >0)){
        taskEffortPerDay = effort/this.getDateDifference(tskStDt, tskEndDt);
        return effortOverTime = this.getDateDifference(this.reportStartDate, tskEndDt)*taskEffortPerDay;
      }
      //report end time lies within task time-frame
      if ((this.getDateDifference(this.reportEndDate, tskEndDt) >0) && (this.getDateDifference(this.reportStartDate, tskStDt) >0)){
        taskEffortPerDay = effort/this.getDateDifference(tskStDt, tskEndDt);
        return effortOverTime = this.getDateDifference(tskStDt, this.reportEndDate)*taskEffortPerDay;
      }
    }else return 0;
  }

  checkAllUsers(){
    this.users.forEach(user => {
      user.checked = this.isSelectedAllUser;
    });
    this.usersSelected();
  }

  usersSelected(){
    this.selectedCheckBoxUsers = [];
    this.selectedCheckBoxUserIds = [];
    this.users.forEach(user => {
      if(user.checked) {
        this.selectedCheckBoxUsers.push(user); 
        this.selectedCheckBoxUserIds.push(user.userId);       
      }else this.isSelectedAllUser = false;
    });//console.log(this.selectedCheckBoxUsers);
  }

  getTasksByUsers(users, callback) {
    this.reportService.getTasksByUsersDAO(users).subscribe(data => {
      this.taskListOfUsers = data;
      callback();
    });
  }

  calculateUtilization(){

  }

  getDateDifference(startDt, endDt){
    return (((new Date(endDt)).valueOf() - (new Date(startDt)).valueOf())/1000/3600/24)+1
  }

}
