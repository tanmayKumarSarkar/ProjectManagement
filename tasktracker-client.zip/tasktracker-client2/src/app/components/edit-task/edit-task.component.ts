import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { ActivatedRoute, Router } from '../../../../node_modules/@angular/router';

declare var $ :any;

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  taskId;
  task;
  taskBackUp;
  taskAttachment;

  //other Variables
  taskTypes;
  taskTypeId;
  projects;
  projectId;
  taskStatuses;
  taskStatusId;
  taskComplexities;
  taskComplexityId;
  taskCategories;
  taskCategoryId;

  taskRework: Boolean;
  taskReworkTypes;
  taskReworkTypeId;
  taskReworkParentId;
  taskReworkObj;
  taskReworkDescription;
  taskReworkDuration;

  //user handeling 
  users;
  filteredAsigneeUsers;
  filteredReviewerUsers;

  taskAsignee;
  taskReviewer;

  validAsignee = false;
  validReviewer = false;

  taskServiceSubscription;

  constructor(private taskService : TaskService, private actvRoute: ActivatedRoute, private router: Router) {
    //this.actvRoute.params.subscribe( params => this.taskId = params.id);
    this.taskId = this.taskService.selectedViewEditTask;    
    this.taskServiceSubscription = this.taskService.propertyChange.subscribe({
      next: (data: String) => {
        if (data === "ModalViewEditTask") {
          this.initViewEditTask();
        }
        if (data === "CloseModalViewEditTask") this.closeViewEditModal();
      }
    });
   }

  ngOnInit () {
    this.loadAllInitialValues();
    if(this.taskId !== undefined) this.getTaskById(this.taskId, (data)=>{
      this.assignFormTaskValues(data);
      this.taskRework = data.taskRework == null ? false : true;
    });
    this.users = this.taskService.allUsers;
    
  }

  initViewEditTask(){
    this.taskId = this.taskService.selectedViewEditTask;
    if(this.taskId) this.getTaskById(this.taskId, (data)=>{
      this.assignFormTaskValues(data);
      this.taskRework = this.task.taskRework == null ? false : true;
    });
    
    this.users = this.taskService.allUsers;
    if(this.users == null || this.users === undefined){
      this.getAllUsers();
    }
  }

  loadAllInitialValues(){
    this.getAllUsers(); 
    this.getAllTaskTypes();
    this.getAllProjects();
    this.getAllTaskStatuses();
    this.getAllTaskComplexities();
    this.getAllTaskCategories();
    this.getAllTaskReworkTypes();
  }

  getAllUsers() {
    this.taskService.getAllUsersDAO().subscribe(data => {
      this.users = this.taskService.allUsers = data;
    });
  }

  getTaskById(id, callback) {
    this.taskService.getTaskByIdDAO(id).subscribe(data => {
      if(data.success){
        this.taskBackUp = this.task = this.taskService.selectedViewEditTask = data.task;
        //console.log(this.task)
        this.formatAndSetAllDates();
        this.setAllUsers();
        callback(this.task);
      }      
    });
  }

  getAllTaskTypes(){
    this.taskService.getAllTaskTypesDAO().subscribe(data => {
      this.taskTypes = this.taskService.taskTypes = data;
    });
  }

  getAllProjects(){
    this.taskService.getAllProjectsDAO().subscribe(data => {
      this.projects = this.taskService.projects = data;
    });
  }

  getAllTaskStatuses(){
    this.taskService.getAllTaskStatusesDAO().subscribe(data => {
      this.taskStatuses = this.taskService.taskStatuses = data;
    });
  }

  getAllTaskComplexities(){
    this.taskService.getAllTaskComplexitiesDAO().subscribe(data => {
      this.taskComplexities = this.taskService.taskComplexities = data;
    });
  }

  getAllTaskCategories(){
    this.taskService.getAllTaskCategoriesDAO().subscribe(data => {
      this.taskCategories = this.taskService.taskCategories = data;
    });
  }

  getAllTaskReworkTypes(){
    this.taskService.getAllTaskReworkTypesDAO().subscribe(data => {
      this.taskReworkTypes = this.taskService.taskReworkTypes = data;
    });
  }

  formatAndSetAllDates () {
    this.task.taskStartDate = this.formatDate(this.task.taskStartDate);
    this.task.taskDevEndDate = this.formatDate(this.task.taskDevEndDate);
    this.task.taskUatEndDate = this.formatDate(this.task.taskUatEndDate);
    this.task.taskProdEndDate = this.formatDate(this.task.taskProdEndDate);
  }

  formatDate(dt){
    if(dt == null || dt ==='') return '';
    else return new Date(dt).toISOString().split('T')[0];
  }
//
  setAllUsers (){
    if(this.task.taskAsignee != null && this.task.taskAsignee !== undefined){
      this.taskAsignee = this.task.taskAsignee.userFirstName;
      //console.log(this.taskAsignee);
    }
    if(this.task.taskReviewer != null && this.task.taskReviewer !== undefined){
      this.taskReviewer = this.task.taskReviewer.userFirstName;
    }
  }

  //user
    //asignee
  asigneeOnKey(e) {
    let temp = this.taskAsignee;
    this.validAsignee = false;
    if(temp != null &&  temp.toString().length>1){
      this.searchAsignee(temp);
      if(this.filteredAsigneeUsers.length > 0){
        this.task.taskAsignee = null;
      }
    }else {
      this.filteredAsigneeUsers = [];
      this.task.taskAsignee = null;
    }
  }

  searchAsignee = val => {
    this.filteredAsigneeUsers = this.users.filter((obj)=>{
      return obj.userFirstName.toLowerCase().includes(val.toLowerCase());
    });
  }

  asigneeSelect(val){
    this.taskAsignee = val.userFirstName;
    this.filteredAsigneeUsers = [];
    this.task.taskAsignee = {
      userId: Number(val.userId)
    };
    this.validAsignee = true;
  }


  //Reviewer
  reviewerOnKey(e) {
    let temp = this.taskReviewer;
    this.validReviewer = false;
    if(temp != null && temp.toString().length>1){
      this.searchReviewer(temp);
      if(this.filteredReviewerUsers.length > 0){
        this.task.taskReviewer = null;
      }
    }else {
      this.filteredReviewerUsers = [];
      this.task.taskReviewer = null;
    }
  }

  searchReviewer = val => {
    this.filteredReviewerUsers = this.users.filter((obj)=>{
      return obj.userFirstName.toLowerCase().includes(val.toLowerCase());
    });
  }

  reviewerSelect(val){
    this.taskReviewer = val.userFirstName;
    this.filteredReviewerUsers = [];
    this.task.taskReviewer = {
      userId : Number(val.userId)
    };
    this.validReviewer = true;
  }
  //End user


  onUpdateSubmit(){
    if(this.validateTask()){
      this.checkTaskRework((data)=>{
        //console.log(this.task, this.task.taskRework, data, data.taskReworkId);
        this.taskService.updateTasksDAO(this.task).subscribe(data => {
          //console.log(this.task);
          if(data != null || data !== undefined) {
            this.task = data.task;
            this.taskService.triggerEvent("updatedTask");
            this.closeViewEditModal();
          }
        });
      });
    }
  }

  checkTaskRework(callback){
    if(this.taskRework) {
      this.taskReworkObj = {
      taskReworkType: {taskReworkTypeId : Number(this.taskReworkTypeId)},
      taskReworkParent: {taskId : Number(this.taskReworkParentId)},
      taskReworkDuration: this.taskReworkDuration,
      taskReworkDescription: this.taskReworkDescription
      }
      this.taskService.saveTaskReworkDAO(this.taskReworkObj).subscribe(data => {
        if(data != null || data !== undefined) {
          this.taskReworkObj = data;
          this.task.taskRework = { taskReworkId : Number(this.taskReworkObj.taskReworkId) };
          this.assignOtherTaskValues();
          callback (data);
        }        
      }); 
    }else{
      this.task.taskRework = undefined;
      this.assignOtherTaskValues();
      callback (this.task);
    }     
  }

  assignOtherTaskValues(){
    this.task.project = {projectId: Number(this.projectId)};
    this.task.taskType = { taskTypeId: Number(this.taskTypeId)};
    this.task.taskStatus = { taskStatusId: Number(this.taskStatusId)};
    this.task.taskComplexity = { taskComplexityId: Number(this.taskComplexityId)};
    this.task.taskCategory = { taskCategoryId: Number(this.taskCategoryId)}; 
  }

  //load the task values to form
  assignFormTaskValues(task){
    if(task.project) this.projectId = task.project.projectId;
    if(task.taskType) this.taskTypeId = task.taskType.taskTypeId;
    if(task.taskStatus) this.taskStatusId =  task.taskStatus.taskStatusId;
    if(task.taskComplexity) this.taskComplexityId =  task.taskComplexity.taskComplexityId;
    if(task.taskCategory) this.taskCategoryId = task.taskCategory.taskCategoryId;
    if(task.taskRework) {
      if(task.taskRework.taskReworkType) this.taskReworkTypeId = task.taskRework.taskReworkType.taskReworkTypeId;
      if(task.taskRework.taskReworkParent) this.taskReworkParentId = task.taskRework.taskReworkParent.taskId;
      this.taskReworkDuration = task.taskRework.taskReworkDuration;
      this.taskReworkDescription = task.taskRework.taskReworkDescription;
    }
  }

  validateTask() {
   
    let isValid = false;
    if(
      this.task.taskName !== '' && this.task.taskName != null && this.task.taskName !== undefined && 
      this.taskTypeId != null && this.taskTypeId !== undefined && 
      this.projectId != null && this.projectId !== undefined && 
      this.task.taskDescription !== '' && this.task.taskDescription != null && this.task.taskDescription !== undefined && 
      this.task.priority !== undefined && this.task.priority != null && this.task.priority.toString() !== '' && 
      this.task.taskStartDate !== undefined && this.task.taskStartDate != null && this.task.taskStartDate.toString() !== '' && 
      this.task.taskDevEndDate !== undefined && this.task.taskDevEndDate != null && this.task.taskDevEndDate.toString() !== '' && 
      this.taskStatusId != null && this.taskStatusId !== undefined && 
      this.task.taskEffort !== undefined && this.task.taskEffort != null && this.task.taskEffort.toString() !== '' && 
      this.taskComplexityId != null && this.taskComplexityId !== undefined && 
      this.taskCategoryId != null && this.taskCategoryId !== undefined  && 
      this.task.taskAsignee !== undefined && this.task.taskAsignee != null && 
      this.task.taskAsignee.userId !== undefined && this.task.taskAsignee.userId != null  && 
      //this.task.taskArtifactDetails !== '' && this.task.taskArtifactDetails != null && this.task.taskArtifactDetails !== undefined  &&
      (this.taskRework ? ( 
          this.taskReworkTypeId !== undefined && this.taskReworkTypeId !== '' &&
          this.taskReworkParentId !== undefined && this.taskReworkParentId !== '' &&
          this.taskReworkDescription !== undefined && this.taskReworkDescription !== '' && 
          this.taskReworkDuration != null && this.taskReworkDuration > 0
        ) : true
      )
    ) {
      return true;
    }else return false;
  }

  deleteTaskByID(task) {
    if(confirm("Are you sure to delete Task: "+task.taskName)) {
      this.taskService.deleteTasksDAO(this.task.taskId).subscribe(data => {
        if(data.success){
          this.taskService.triggerEvent("updatedTask");
          this.closeViewEditModal();
        }
      });
      return;
    }    
  }

  closeViewEditModal(){
    $('#viewTaskModal').modal('toggle');
    this.clearData();
  }

  clearData (){
    this.task = null;
    this.taskTypeId = null;
    this.projectId = null;
    this.taskStatusId = null;
    this.taskComplexityId = null;
    this.taskCategoryId = null;
    this.taskReworkTypeId = null;
    this.taskReworkParentId = undefined;
    this.taskReworkDescription = null;
    this.taskReworkDuration = null;
    this.taskAsignee = null;
    this.taskReviewer = null;
  }

}
