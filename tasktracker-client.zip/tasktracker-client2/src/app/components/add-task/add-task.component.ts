import { Component, OnInit, ElementRef, HostListener, Input, Directive } from '@angular/core';
import { Task } from '../../entities/Task';

import {Observable} from 'rxjs';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { TaskService } from '../../services/task.service';
import { User } from '../../entities/User';
import { Router } from '../../../../node_modules/@angular/router';

declare var $ :any;

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  task : Task;
  users;
  taskTypes;
  taskTypeId;
  projects;
  projectId;
  taskStatuses;
  taskStatusId;
  taskComplexities;
  taskComplexityId;
  taskCategories;
  taskCategoryId;
  Select;

  taskRework: Boolean;
  taskReworkTypes;
  taskReworkTypeId;
  taskReworkParentId;
  taskReworkObj;
  taskReworkDescription;
  taskReworkDuration;

  //asignee & Reviewer
  filteredAsigneeUsers;
  filteredReviewerUsers;
  taskAsignee;
  taskReviewer;
  validAsignee = false;
  validReviewer = false;
  taskServiceSubscription;

  constructor(private taskService: TaskService, private eRef: ElementRef, private router: Router) { 
    this.task = new Task();
    this.taskRework = false;
    this.taskServiceSubscription = this.taskService.propertyChange.subscribe({
      next: (data: String) => {
        if (data === "ModalNewFreshTask") {
          this.loadNewTaskDefaultValues();
        }
        if (data === "ModalNewCopyTask") {
          this.initViewAddTask();
        }
        if (data === "CloseModalAddViewTask") {
          this.closeModal();
        }
      }
    });
  }

  ngOnInit() {
    this.loadAllInitialValues();
  }

  loadAllInitialValues(){
    this.getAllUsers(); 
    this.getAllTaskTypes();
    this.getAllProjects();
    this.getAllTaskStatuses();
    this.getAllTaskComplexities();
    this.getAllTaskCategories();
    this.getAllTaskReworkTypes();
  }

  initViewAddTask(){
    let tempTask = this.taskService.selectedAddViewTask;
    if(tempTask.taskId) this.getTaskById(tempTask.taskId, (data)=>{
      delete data["taskId"];
      delete data["checked"];
      this.assignFormTaskValues(data);
      this.setAllUsers(this.taskService.selectedAddViewTask);
      this.taskRework = this.task.taskRework == null ? false : true;
    });
    // delete this.task["taskId"];
    // delete this.task["checked"];
    //console.log(this.task)    
  }

  getAllUsers() {
    this.taskService.getAllUsersDAO().subscribe(data => {
      this.users = this.taskService.allUsers = data;
    });
  }

  getTaskById(id, callback) {
    this.taskService.getTaskByIdDAO(id).subscribe(data => {
      if(data.success){
        this.task = this.taskService.selectedViewEditTask = data.task;
        callback(this.task);
      }      
    });
  }

  getAllTaskTypes(){
    this.taskService.getAllTaskTypesDAO().subscribe(data => {
      this.taskTypes = this.taskService.taskTypes = data;
    });
  }

  getAllProjects(){
    this.taskService.getAllProjectsDAO().subscribe(data => {
      this.projects = this.taskService.projects = data;
    });
  }

  getAllTaskStatuses(){
    this.taskService.getAllTaskStatusesDAO().subscribe(data => {
      this.taskStatuses = this.taskService.taskStatuses = data;
    });
  }

  getAllTaskComplexities(){
    this.taskService.getAllTaskComplexitiesDAO().subscribe(data => {
      this.taskComplexities = this.taskService.taskComplexities = data;
    });
  }

  getAllTaskCategories(){
    this.taskService.getAllTaskCategoriesDAO().subscribe(data => {
      this.taskCategories = this.taskService.taskCategories = data;
    });
  }

  getAllTaskReworkTypes(){
    this.taskService.getAllTaskReworkTypesDAO().subscribe(data => {
      this.taskReworkTypes = this.taskService.taskReworkTypes = data;
    });
  }

  //updating users
  ngAfterContentChecked() {
    this.users = this.taskService.allUsers;
  }

  //asignee
  asigneeOnKey(e) {
    let temp = this.taskAsignee;
    this.validAsignee = false;
    if(temp != null &&  temp.toString().length>1){
      this.searchAsignee(temp);
      if(this.filteredAsigneeUsers.length > 0){
        this.task.taskAsignee = null;
      }
    }else {
      this.filteredAsigneeUsers = [];
      this.task.taskAsignee = null;
    }
  }

  searchAsignee = val => {
    this.filteredAsigneeUsers = this.users.filter((obj)=>{
      return obj.userFirstName.toLowerCase().includes(val.toLowerCase());
    });
  }

  asigneeSelect(val){
    this.taskAsignee = val.userFirstName;
    this.filteredAsigneeUsers = [];
    this.task.taskAsignee = {
      userId: Number(val.userId)
    };
    this.validAsignee = true;
  }


  //Reviewer
  reviewerOnKey(e) {
    let temp = this.taskReviewer;
    this.validReviewer = false;
    if(temp != null && temp.toString().length>1){
      this.searchReviewer(temp);
      if(this.filteredReviewerUsers.length > 0){
        this.task.taskReviewer = null;
      }
    }else {
      this.filteredReviewerUsers = [];
      this.task.taskReviewer = null;
    }
  }

  searchReviewer = val => {
    this.filteredReviewerUsers = this.users.filter((obj)=>{
      return obj.userFirstName.toLowerCase().includes(val.toLowerCase());
    });
  }

  reviewerSelect(val){
    this.taskReviewer = val.userFirstName;
    this.filteredReviewerUsers = [];
    this.task.taskReviewer = {
      userId : Number(val.userId)
    };
    this.validReviewer = true;
  }

  closeModal(){
    $('#addTaskModal').modal('toggle');
    this.clearData();
  }

  onAddSubmit(){
    //check validations
    if(this.validateTask()){
      this.checkTaskRework((data)=>{
        this.taskService.saveTasksDAO(this.task).subscribe(data => {
          if(data != null || data !== undefined) {
            this.task = data;
            this.taskService.triggerEvent("newtask");
            this.task.taskId = null;
            this.task.taskRework = null;
            $('#addTaskModal').modal('toggle');
            this.clearData();
          }
        });
      });
    }
  }

  checkTaskRework(callback){
    if(this.taskRework) {
      this.taskReworkObj = {
      taskReworkType: {taskReworkTypeId : Number(this.taskReworkTypeId)},
      taskReworkParent: {taskId : Number(this.taskReworkParentId)},
      taskReworkDuration: this.taskReworkDuration,
      taskReworkDescription: this.taskReworkDescription
      }
      this.taskService.saveTaskReworkDAO(this.taskReworkObj).subscribe(data => {
        if(data != null || data !== undefined) {
          this.taskReworkObj = data;
          this.task.taskRework = { taskReworkId : Number(this.taskReworkObj.taskReworkId) };
          this.assignOtherTaskValues();
          callback (data);
        }        
      }); 
    }else{
      this.task.taskRework = undefined;
      this.assignOtherTaskValues();
      callback (this.task);
    }     
  }

  assignOtherTaskValues(){
    this.task.project = {projectId: Number(this.projectId)};
    this.task.taskType = { taskTypeId: Number(this.taskTypeId)};
    this.task.taskStatus = { taskStatusId: Number(this.taskStatusId)};
    this.task.taskComplexity = { taskComplexityId: Number(this.taskComplexityId)};
    this.task.taskCategory = { taskCategoryId: Number(this.taskCategoryId)}; 
  }

  //load the task values to form
  assignFormTaskValues(task){
    this.task.taskName = undefined;
    this.task.trackingNumber = undefined;
    this.task.taskDescription = undefined;
    this.task.taskArtifactDetails = undefined;
    this.task.taskCheckpoint = undefined;
    if(task.project) this.projectId = task.project.projectId;
    if(task.taskType) this.taskTypeId = task.taskType.taskTypeId;
    if(task.taskStatus) this.taskStatusId =  task.taskStatus.taskStatusId;
    if(task.taskComplexity) this.taskComplexityId =  task.taskComplexity.taskComplexityId;
    if(task.taskCategory) this.taskCategoryId = task.taskCategory.taskCategoryId;
    if(task.taskRework) {
      if(task.taskRework.taskReworkType) this.taskReworkTypeId = task.taskRework.taskReworkType.taskReworkTypeId;
      if(task.taskRework.taskReworkParent) this.taskReworkParentId = task.taskRework.taskReworkParent.taskId;
      this.taskReworkDuration = task.taskRework.taskReworkDuration;
      this.taskReworkDescription = task.taskRework.taskReworkDescription;
    }
  }

  setAllUsers (task){
    if(task.taskAsignee != null && task.taskAsignee !== undefined){
      this.taskAsignee = task.taskAsignee.userFirstName;
    }
    if(task.taskReviewer != null && task.taskReviewer !== undefined){
      this.taskReviewer = task.taskReviewer.userFirstName;
    }
  }

  validateTask() {
   
    let isValid = false;
    if(
      this.task.taskName !== '' && this.task.taskName != null && this.task.taskName !== undefined && 
      this.taskTypeId != null && this.taskTypeId !== undefined && 
      this.projectId != null && this.projectId !== undefined && 
      //this.task.trackingNumber !== '' && this.task.trackingNumber != null && this.task.trackingNumber !== undefined && 
      this.task.taskDescription !== '' && this.task.taskDescription != null && this.task.taskDescription !== undefined && 
      this.task.priority !== undefined && this.task.priority != null && this.task.priority.toString() !== '' && 
      this.task.taskStartDate !== undefined && this.task.taskStartDate != null && this.task.taskStartDate.toString() !== '' && 
      this.task.taskDevEndDate !== undefined && this.task.taskDevEndDate != null && this.task.taskDevEndDate.toString() !== '' && 
      //this.task.taskUatEndDate !== undefined && this.task.taskUatEndDate != null && this.task.taskUatEndDate.toString() !== '' && 
      //this.task.taskProdEndDate !== undefined && this.task.taskProdEndDate != null && this.task.taskProdEndDate.toString() !== '' && 
      this.taskStatusId != null && this.taskStatusId !== undefined && 
      this.task.taskEffort !== undefined && this.task.taskEffort != null && this.task.taskEffort.toString() !== '' && 
      this.taskComplexityId != null && this.taskComplexityId !== undefined && 
      this.taskCategoryId != null && this.taskCategoryId !== undefined  && 
      this.task.taskAsignee !== undefined && this.task.taskAsignee != null && 
      this.task.taskAsignee.userId !== undefined && this.task.taskAsignee.userId != null  && 
      //this.task.taskReviewer !== undefined && this.task.taskReviewer != null && 
      //this.task.taskReviewer.userId !== undefined && this.task.taskReviewer.userId != null  && 
      //this.task.taskArtifactDetails !== '' && this.task.taskArtifactDetails != null && this.task.taskArtifactDetails !== undefined  &&
      (this.taskRework ? ( 
          this.taskReworkTypeId !== undefined && this.taskReworkTypeId !== '' &&
          this.taskReworkParentId !== undefined && this.taskReworkParentId !== '' &&
          this.taskReworkDescription !== undefined && this.taskReworkDescription !== '' && 
          this.taskReworkDuration != null && this.taskReworkDuration > 0
        ) : true
      )
    ) {
      return true;
    }else return false;
  }

  clearData (){
    //this.task = {};
    this.task.taskName = undefined;
    this.task.trackingNumber = undefined;
    this.task.taskDescription = undefined;
    this.task.taskArtifactDetails = undefined;
    this.task.taskCheckpoint = undefined;
    this.task.taskStartDate = undefined;
    this.task.taskDevEndDate = undefined;
    this.task.taskUatEndDate = undefined;
    this.task.taskProdEndDate = undefined;
    this.task.priority = undefined;
    this.task.taskEffort = undefined;
    this.taskTypeId = undefined;
    this.projectId = undefined;
    this.taskStatusId = undefined;
    this.taskComplexityId = undefined;
    this.taskCategoryId = undefined;
    this.taskReworkTypeId = undefined;
    this.taskReworkParentId = undefined;
    this.taskReworkDescription = undefined;
    this.taskReworkDuration = undefined;
    this.taskAsignee = undefined;
    this.taskReviewer = undefined;
  }

  //assigning default values for the New catagory Task
  loadNewTaskDefaultValues(){
    this.projectId = this.projects[0].projectId; //JASPER
    this.taskTypeId = this.taskTypes[2].taskTypeId; //Other
    //this.task.taskStartDate = new Date().toISOString().split('T')[0]; //this.LocalDateInISOFormat();
    //console.log(this.task.taskStartDate);
  }

  LocalDateInISOFormat(){
    let dt = new Date().toLocaleString().split(', ')[0].split('/').join('-');
    return dt;
  }


}
