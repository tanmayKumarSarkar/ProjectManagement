import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service';

@Component({
  selector: 'app-task-comment',
  templateUrl: './task-comment.component.html',
  styleUrls: ['./task-comment.component.css']
})
export class TaskCommentComponent implements OnInit {

  taskServiceSubscription;
  comments;
  taskCommentText;
  comment: {
    commentDetails: String,
    commentType: "tasktracker",
    commentAuthor: {
        userId: Number
    },
    commentTask: {
        taskId: Number
    }
  } 

  constructor(private taskService: TaskService) {
    this.taskServiceSubscription = this.taskService.propertyChange.subscribe({
      next: (data: String) => {
        if (data === "SelectedTaskForView") {
          this.getCommentsForTask();
          console.log(this.comments);
        }
      }
    });
   }

  ngOnInit() {
  }

  getCommentsForTask(){
    this.taskService.getCommentsForTaskDAO(this.taskService.selectedTaskOnView.taskId).subscribe(data => {
      this.comments = data;
    });
  }

  commitSubmit(){
    this.comment = {
      commentDetails: this.taskCommentText,
      commentType: "tasktracker",
      commentAuthor: {
        userId: Number(4)
      },
      commentTask: {
        taskId: Number(this.taskService.selectedTaskOnView.taskId)
      }
    }
    this.taskService.saveTaskCommentDAO(this.comment).subscribe(data => {
      this.getCommentsForTask();
      //this.comments.push(data);
    });
    this.taskCommentText = '';
  }

}
