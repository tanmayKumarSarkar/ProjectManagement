import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { Task } from '../../entities/Task';


declare var jquery:any;
declare var $ :any;


@Component({
  selector: 'app-view-tasks',
  templateUrl: './view-tasks.component.html',
  styleUrls: ['./view-tasks.component.css']
})
export class ViewTasksComponent implements OnInit {

  tasks;
  taskServiceSubscription;
  selectedTaskOnView;
  pageSize = 25;
  searchTask: Task;
  sortTaskField = 'taskStartDate';
  sortTaskSubField = '';
  sortTaskDesc = true;
  selectedViewEditTask;
  p;

  selectedCheckBoxTasks=[];


  constructor(private taskService: TaskService) {
    this.searchTask = new Task();
    this.taskServiceSubscription = this.taskService.propertyChange.subscribe({
      next: (data: String) => {
        if (data === "newtask" || data === "updatedTask") {
          this.getAllTasks();
        }
      }
    });
   }

  ngOnInit() {
    this.getAllTasks();
  }

  getAllTasks() {
    this.taskService.getAllTasksDAO().subscribe(data => {
      this.tasks = this.taskService.allTasks = data;
    });
  }
  
  edit(){
    //console.log(this.tasks);
  }

  ngAfterContentChecked() {
    this.tasks = this.taskService.allTasks;
  }

  selectTaskForView(task){
    this.selectedTaskOnView = this.taskService.selectedTaskOnView = task;
    this.taskService.triggerEvent("SelectedTaskForView");
    if(!$('.sliderBottomPannel').hasClass('bottomSlideActive')) {
      $('.sliderBottomPannel').toggleClass('bottomSlideActive');
      this.setPageForHalfScreen();
    }
    //console.log(task);
  }

  sortFilter(sortField, sortSubField){
    this.sortTaskField = sortField;
    if(sortSubField !== '') this.sortTaskSubField = sortSubField;
    this.sortTaskDesc = ! this.sortTaskDesc;
  }

  viewTaskOnModal(taskId){
    //console.log(taskId);
    this.selectedViewEditTask = this.taskService.selectedViewEditTask = taskId;
    this.taskService.triggerEvent("ModalViewEditTask");
    $('#viewTaskModal').modal('toggle');
  }

  closeViewEditModal(){
    this.taskService.triggerEvent("CloseModalViewEditTask");
  }

  closeAddViewModal(){
    this.taskService.triggerEvent("CloseModalAddViewTask");
  }

  taskSelected(){
    this.selectedCheckBoxTasks = [];
    this.tasks.forEach(task => {
      if(task.checked) {
        // let taskFound = this.selectedCheckBoxTasks.find(chkTask => task.taskId === chkTask.taskId);
        // console.log(taskFound);
        this.selectedCheckBoxTasks.push(task);        
      }
    });
  }

  newTaskOnModal(){
    this.taskService.triggerEvent("ModalNewFreshTask");
  }

  copyTaskOnModal(task){
    this.taskService.selectedAddViewTask = task;
    this.taskService.triggerEvent("ModalNewCopyTask");
    $('#addTaskModal').modal('toggle');
  }

  deleteTasks(selectedTasks){
    if(confirm("Are you sure to delete selected Tasks?")) {
      selectedTasks.forEach(task => {
        this.taskService.deleteTasksDAO(task.taskId).subscribe(data => {
          if(data.success){
            this.getAllTasks();
          }
        });
      });
      return;
    }
  }

  slideBottomPannel(){
    if($('.sliderBottomPannel').hasClass('bottomSlideActive')){
      this.setPageForFullScreen();
    }else this.setPageForHalfScreen();
    $('.sliderBottomPannel').toggleClass('bottomSlideActive');
  }

  setPageForFullScreen(){
    this.pageSize = 25;
  }
  
  setPageForHalfScreen(){
    this.pageSize = 17;
  }

}
