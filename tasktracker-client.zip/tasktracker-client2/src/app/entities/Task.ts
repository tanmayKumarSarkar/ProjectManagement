
export class Task {

        taskId: number;
        taskName: string;
        taskType: { taskTypeId: Number };
        project: { projectId: Number };
        trackingNumber: string;
        taskDescription: string;
        priority: number;
        taskStartDate: any;
        taskDevEndDate: Date;
        taskUatEndDate: Date;
        taskProdEndDate: Date;
        taskCreateDate: Date;
        taskStatus: { taskStatusId: Number };
        taskEffort: Number;
        taskPlannedEffort: Number;
        taskComplexity: { taskComplexityId: Number };
        taskCategory: { taskCategoryId: Number };
        taskAsignee: { userId: Number };
        taskReviewer: { userId: Number };
        taskArtifactDetails: String;
        taskCheckpoint: String;
        taskAttachment: { attachmentId: Number };
        taskRework: { taskReworkId: Number };
}