export class User {

    userId: Number;
    userFirstName: String;
    userRole: String;
    userPermission: Object;
    
}