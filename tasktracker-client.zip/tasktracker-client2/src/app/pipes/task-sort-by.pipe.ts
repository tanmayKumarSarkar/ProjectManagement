import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'taskSortBy'
})
export class TaskSortByPipe implements PipeTransform {

  transform(tasks: Array<any>, column: any, subColumn: any, reverse: boolean = false): any {
    if (tasks === undefined) return
    const order = reverse ? -1 : 1;
    //console.log(column, ":", subColumn, ":");
    if(subColumn !== undefined && subColumn !== '') {
      return tasks.sort((first: any, second: any): number => {
        //console.log(first, ":", second, ":");
        if (first[column] == null) return -1*order;
        if (second[column] == null) return 1*order;
        const valFirst = first[column][subColumn];
        const valSecond = second[column][subColumn];
        //console.log(valFirst, valSecond, (valFirst < valSecond));
        return (valFirst === valSecond) ? 0 : (valFirst < valSecond) ? -1*order : 1*order
      });
    }
    tasks.forEach(task => {
      if(task[column] == null) task[column] = '';
    });
    return tasks.sort((first: any, second: any): number => {
      const valFirst = first[column];
      const valSecond = second[column];
      //console.log(valFirst, valSecond, (valFirst < valSecond), (valFirst - valSecond));
      return (valFirst === valSecond) ? 0 : (valFirst < valSecond) ? -1*order : 1*order
    });
  }

}
