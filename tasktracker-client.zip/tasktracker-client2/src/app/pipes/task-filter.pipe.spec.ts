import { TaskFilterPipe } from './task-filter.pipe';

describe('TaskFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TaskFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
