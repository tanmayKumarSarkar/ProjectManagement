import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '../../../node_modules/@angular/common';

@Pipe({
  name: 'taskFilter'
})
export class TaskFilterPipe implements PipeTransform {

  transform(tasks: Array<any>, 
            taskName: string, 
            taskTypeName: string, 
            trackingNumber: string,
            projectName: string,
            taskCategory : string,
            priority : string,
            taskComplexity : string,
            taskEffort : string,
            taskStatus : string,
            taskStartDate : string,
            taskDevEndDate : string,
            taskUatEndDate : string,
            taskProdEndDate : string,
            taskAsignee : string,
            taskReviewer : string
    ){
    if (tasks && tasks.length){
        return tasks.filter(task =>{
            if ((taskName && task.taskName == null) ||(taskName && task.taskName.toLowerCase().indexOf(taskName.toLowerCase())) === -1){
                return false;
            }
            if ((taskTypeName && task.taskType == null) || (taskTypeName && (task.taskType != null) && task.taskType.taskTypeName.toLowerCase().indexOf(taskTypeName.toLowerCase()) === -1)){
                return false;
            }
            if ((trackingNumber && task.trackingNumber == null) || (trackingNumber && (task.trackingNumber != null) && task.trackingNumber.toLowerCase().indexOf(trackingNumber.toLowerCase()) === -1)){
                return false;
            }
            if ((projectName && task.project == null) || (projectName && (task.project != null) && task.project.projectName.toLowerCase().indexOf(projectName.toLowerCase()) === -1)){
                return false;
            }
            if ((taskCategory && task.taskCategory == null) || (taskCategory && (task.taskCategory != null) && task.taskCategory.taskCategoryName.toLowerCase().indexOf(taskCategory.toLowerCase()) === -1)){
                return false;
            }
            if ((priority && task.priority == null) || (priority && (task.priority != null) && String(task.priority).toLowerCase().indexOf(priority.toLowerCase()) === -1)){
                return false;
            }
            if ((taskComplexity && task.taskComplexity == null) || (taskComplexity && (task.taskComplexity != null) && task.taskComplexity.taskComplexityName.toLowerCase().indexOf(taskComplexity.toLowerCase()) === -1)){
                return false;
            }
            if ((taskEffort && task.taskEffort == null) || (taskEffort && (task.taskEffort != null) && String(task.taskEffort).toLowerCase().indexOf(taskEffort.toLowerCase()) === -1)){
                return false;
            }
            if ((taskStatus && task.taskStatus == null) || (taskStatus && (task.taskStatus != null) && task.taskStatus.taskStatusName.toLowerCase().indexOf(taskStatus.toLowerCase()) === -1)){
                return false;
            }
           
            if (this.datesDidNotMatch(taskStartDate, task.taskStartDate)){
                return false;
            }

            if (this.datesDidNotMatch(taskDevEndDate, task.taskDevEndDate)){
                return false;
            }

            if (this.datesDidNotMatch(taskUatEndDate, task.taskUatEndDate)){
                return false;
            }

            if (this.datesDidNotMatch(taskProdEndDate, task.taskProdEndDate)){
                return false;
            }

            if ((taskAsignee && task.taskAsignee == null) || (taskAsignee && (task.taskAsignee != null) && task.taskAsignee.userFirstName.toLowerCase().indexOf(taskAsignee.toLowerCase()) === -1)){
                return false;
            }
            
            if ((taskReviewer && task.taskReviewer == null) || (taskReviewer && (task.taskReviewer != null) && task.taskReviewer.userFirstName.toLowerCase().indexOf(taskReviewer.toLowerCase()) === -1)){
                return false;
            }

            return true;
       })
    }
    else{
        return tasks;
    }
}

//compare Dates whether empty or did not matched retun false if matches
datesDidNotMatch(inputDate, matchingDate) {
    if(inputDate){
        if(!matchingDate) return true;

        let matchingDateTemp = new Date(matchingDate);
        inputDate = inputDate.replace(/[^a-zA-Z0-9 ]/g, '-');

        let dateArray = inputDate.split('-');
        let checkDay = dateArray[0] ? dateArray[0] : '';
        let checkMonth =  dateArray[1] ? dateArray[1] : '';
        let checkYear =  dateArray[2] ? dateArray[2] : '';

        //check and correction
        checkDay = checkDay.length > 0 && checkDay.length < 2 ? "0" + checkDay : checkDay;
        checkMonth = checkMonth.length > 0 && checkMonth.length < 2 && !isNaN(checkMonth) ? "0" + checkMonth : checkMonth;

        if (checkMonth && isNaN(checkMonth)) {
            checkYear = checkYear.length > 2 ? checkYear : ".." + checkYear;
            let tempDate = ".*" + checkDay + " " + checkMonth.replace(/^[a-z]/, x => x.toUpperCase()) + " " + checkYear + ".*";
            let regex = new RegExp(tempDate);
            if (regex.test(matchingDateTemp.toUTCString())) return false;
        }

        let tempDate = checkYear + "-" + checkMonth + "-" + checkDay;
        //console.log(tempDate, " : ", matchingDateTemp.getDate(), " : ", matchingDateTemp.getDay(), " : ", matchingDateTemp.getFullYear(), " : ", matchingDateTemp.getMonth(), " : ", matchingDateTemp.getUTCDate(), " : ", matchingDateTemp.toUTCString());
        if (matchingDateTemp.toISOString().split('T')[0].search(tempDate) >= 0) {
            return false;
        } 

        if (matchingDateTemp.toISOString().split('T')[0].search(inputDate.split('-').reverse().join('-')) >= 0) {
            return false;
        }

        if (matchingDateTemp.toUTCString().toLowerCase().search(inputDate.split('-').join(' ')) >= 0) {

            return false;
        }
        
        else return true;

    }else true;
}

}
