import { TaskSortByPipe } from './task-sort-by.pipe';

describe('TaskSortByPipe', () => {
  it('create an instance', () => {
    const pipe = new TaskSortByPipe();
    expect(pipe).toBeTruthy();
  });
});
